// Package auth defines protocol-agnostic authentication types for smithy
// clients.
package auth
